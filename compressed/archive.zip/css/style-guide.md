# Style Guide

## Colors

- background color: #f1f5f9 | hsl(210, 40%, 96%) | rgb(241, 245, 249)
- box-background color: #eeeeee | hsl(0, 0%, 93%) | rgb(238, 238, 238)

## Typograpghy

- Family: "Open Sans", sans-serif(<https://fonts.gstatic.com>)
- Weights: 300,500
- Paragragh Font Size: 15px
- Description Font Size: 13px
- Description Line Height: 1.6
